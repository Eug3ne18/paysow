package com.ewallet.controller;

import com.ewallet.model.Transaction;
import com.ewallet.model.User;
import com.ewallet.service.WalletService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@RestController
public class WalletController {

    @Autowired
    private WalletService walletService;

    @Autowired
    private SpringTemplateEngine templateEngine;

    private ResponseEntity<String> serveHtml(String templateName) {
        String html = templateEngine.process(templateName, new Context());
        return ResponseEntity.ok().contentType(MediaType.TEXT_HTML).body(html);
    }

    private User getSessionUser(HttpSession session) {
        Long userId = (Long) session.getAttribute("userId");
        if (userId == null) return null;
        return walletService.findById(userId).orElse(null);
    }

    @GetMapping("/")
    public ResponseEntity<String> index() { return serveHtml("index"); }

    @GetMapping("/signup")
    public ResponseEntity<String> signupPage() { return serveHtml("signup"); }

    @PostMapping("/api/register")
    public ResponseEntity<?> register(@RequestParam String fullName,
                                       @RequestParam String email,
                                       @RequestParam String phone,
                                       @RequestParam String pin) {
        try {
            if (!pin.matches("\\d{4,6}"))
                return ResponseEntity.badRequest().body(java.util.Map.of("success", false, "message", "PIN must be 4-6 digits."));
            User user = walletService.register(fullName, email, phone, pin);
            return ResponseEntity.ok(java.util.Map.of("success", true, "message", "Registration successful! Please login.", "userId", user.getId()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(java.util.Map.of("success", false, "message", e.getMessage()));
        }
    }

    @PostMapping("/api/login")
    public ResponseEntity<?> login(@RequestParam String phone,
                                    @RequestParam String pin,
                                    HttpSession session) {
        Optional<User> opt = walletService.findByPhone(phone);
        if (opt.isPresent() && walletService.checkPin(opt.get(), pin)) {
            session.setAttribute("userId", opt.get().getId());
            return ResponseEntity.ok(java.util.Map.of("success", true, "message", "Login successful"));
        }
        return ResponseEntity.status(401).body(java.util.Map.of("success", false, "message", "Invalid phone number or PIN"));
    }

    @PostMapping("/api/logout")
    public ResponseEntity<?> logout(HttpSession session) {
        session.invalidate();
        return ResponseEntity.ok(java.util.Map.of("success", true));
    }

    @GetMapping("/dashboard")
    public ResponseEntity<String> dashboard(HttpSession session) {
        if (getSessionUser(session) == null) return ResponseEntity.status(302).header("Location", "/").build();
        return serveHtml("dashboard");
    }

    @GetMapping("/cashin")
    public ResponseEntity<String> cashinPage(HttpSession session) {
        if (getSessionUser(session) == null) return ResponseEntity.status(302).header("Location", "/").build();
        return serveHtml("cashin");
    }

    @GetMapping("/cashout")
    public ResponseEntity<String> cashoutPage(HttpSession session) {
        if (getSessionUser(session) == null) return ResponseEntity.status(302).header("Location", "/").build();
        return serveHtml("cashout");
    }

    @GetMapping("/inbox")
    public ResponseEntity<String> inboxPage(HttpSession session) {
        if (getSessionUser(session) == null) return ResponseEntity.status(302).header("Location", "/").build();
        return serveHtml("inbox");
    }

    @GetMapping("/profile")
    public ResponseEntity<String> profilePage(HttpSession session) {
        if (getSessionUser(session) == null) return ResponseEntity.status(302).header("Location", "/").build();
        return serveHtml("profile");
    }

    @GetMapping("/delete")
    public ResponseEntity<String> deletePage(HttpSession session) {
        if (getSessionUser(session) == null) return ResponseEntity.status(302).header("Location", "/").build();
        return serveHtml("delete");
    }

    @GetMapping("/api/me")
    public ResponseEntity<?> getMe(HttpSession session) {
        User user = getSessionUser(session);
        if (user == null) return ResponseEntity.status(401).body(java.util.Map.of("error", "Not logged in"));
        return ResponseEntity.ok(java.util.Map.of(
                "id", user.getId(),
                "fullName", user.getFullName(),
                "email", user.getEmail(),
                "phone", user.getPhone(),
                "balance", user.getBalance(),
                "createdAt", user.getCreatedAt().toString()
        ));
    }

    @PostMapping("/api/cashin")
    public ResponseEntity<?> doCashIn(@RequestParam BigDecimal amount,
                                       @RequestParam(required = false) String description,
                                       HttpSession session) {
        User user = getSessionUser(session);
        if (user == null) return ResponseEntity.status(401).body(java.util.Map.of("error", "Not logged in"));
        try {
            Transaction tx = walletService.cashIn(user, amount, description);
            user = walletService.findById(user.getId()).orElse(user);
            return ResponseEntity.ok(java.util.Map.of(
                    "success", true, "message", "Cash in successful",
                    "referenceNo", tx.getReferenceNo(),
                    "amount", tx.getAmount(),
                    "newBalance", user.getBalance()
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(java.util.Map.of("success", false, "message", e.getMessage()));
        }
    }

    @PostMapping("/api/cashout")
    public ResponseEntity<?> doCashOut(@RequestParam BigDecimal amount,
                                        @RequestParam String recipientPhone,
                                        HttpSession session) {
        User user = getSessionUser(session);
        if (user == null) return ResponseEntity.status(401).body(java.util.Map.of("error", "Not logged in"));

        // Validate recipient phone present
        if (recipientPhone == null || recipientPhone.isBlank())
            return ResponseEntity.badRequest().body(java.util.Map.of("success", false, "message", "Recipient phone number is required."));

        try {
            // ✅ Pass recipientPhone — CashOutOperation handles all logic
            Transaction tx = walletService.cashOut(user, amount, recipientPhone);
            user = walletService.findById(user.getId()).orElse(user);
            return ResponseEntity.ok(java.util.Map.of(
                    "success", true,
                    "message", "Cash out successful",
                    "referenceNo", tx.getReferenceNo(),
                    "amount", tx.getAmount(),
                    "newBalance", user.getBalance()
            ));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(java.util.Map.of("success", false, "message", e.getMessage()));
        }
    }

    // ✅ NEW: look up a user by phone so cashout.html can preview recipient name
    @GetMapping("/api/lookup")
    public ResponseEntity<?> lookupByPhone(@RequestParam String phone, HttpSession session) {
        if (getSessionUser(session) == null)
            return ResponseEntity.status(401).body(java.util.Map.of("error", "Not logged in"));
        return walletService.findByPhone(phone)
                .map(u -> ResponseEntity.ok((Object) java.util.Map.of(
                        "fullName", u.getFullName(),
                        "phone", u.getPhone()
                )))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/api/transactions")
    public ResponseEntity<?> getTransactions(HttpSession session) {
        User user = getSessionUser(session);
        if (user == null) return ResponseEntity.status(401).body(java.util.Map.of("error", "Not logged in"));
        List<Transaction> txs = walletService.getTransactions(user);
        List<java.util.Map<String, Object>> result = txs.stream().map(tx -> {
            java.util.Map<String, Object> m = new java.util.LinkedHashMap<>();
            m.put("id", tx.getId());
            m.put("type", tx.getType().name());
            m.put("amount", tx.getAmount());
            m.put("balanceBefore", tx.getBalanceBefore());
            m.put("balanceAfter", tx.getBalanceAfter());
            m.put("description", tx.getDescription());
            m.put("referenceNo", tx.getReferenceNo());
            m.put("status", tx.getStatus().name());
            m.put("createdAt", tx.getCreatedAt().toString());
            return m;
        }).toList();
        return ResponseEntity.ok(result);
    }

    @PostMapping("/api/profile")
    public ResponseEntity<?> updateProfile(@RequestParam String fullName,
                                            @RequestParam String email,
                                            @RequestParam String phone,
                                            @RequestParam(required = false) String newPin,
                                            HttpSession session) {
        User user = getSessionUser(session);
        if (user == null) return ResponseEntity.status(401).body(java.util.Map.of("error", "Not logged in"));
        try {
            walletService.updateProfile(user, fullName, email, phone, newPin);
            return ResponseEntity.ok(java.util.Map.of("success", true, "message", "Profile updated"));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(java.util.Map.of("success", false, "message", e.getMessage()));
        }
    }

    @DeleteMapping("/api/account")
    public ResponseEntity<?> deleteAccount(HttpSession session) {
        User user = getSessionUser(session);
        if (user == null) return ResponseEntity.status(401).body(java.util.Map.of("error", "Not logged in"));
        walletService.deleteAccount(user);
        session.invalidate();
        return ResponseEntity.ok(java.util.Map.of("success", true, "message", "Account deleted"));
    }
}
